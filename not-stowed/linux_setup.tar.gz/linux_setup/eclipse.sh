cd ~/Downloads/NuEclipse_V1.02.021_Linux_Setup/eclipse && ./eclipse

